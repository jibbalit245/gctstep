"""
models/features.py
Feature engineering pipeline for GC gold futures ML model.
Builds all features from price + alt data with NO look-ahead bias.

Usage:
    from models.features import build_feature_matrix
    X, y = build_feature_matrix(df_ohlcv, df_alt)
"""

import pandas as pd
import numpy as np
import pandas_ta as ta
from pathlib import Path
from loguru import logger
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import FEATURES, BASE_DIR

CACHE_DIR = BASE_DIR / "data" / "cache"


def build_price_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Technical features from OHLCV data.
    All features are point-in-time — no future data used.
    """
    f = pd.DataFrame(index=df.index)

    # ── Returns ────────────────────────────────────────────
    f["ret_1"]  = df["close"].pct_change(1)
    f["ret_4"]  = df["close"].pct_change(4)
    f["ret_12"] = df["close"].pct_change(12)
    f["ret_24"] = df["close"].pct_change(24)
    f["ret_48"] = df["close"].pct_change(48)

    # ── Momentum ───────────────────────────────────────────
    f["rsi_14"]    = ta.rsi(df["close"], 14)
    f["rsi_7"]     = ta.rsi(df["close"], 7)
    f["roc_14"]    = ta.roc(df["close"], 14)

    # ── Trend ──────────────────────────────────────────────
    ema20 = ta.ema(df["close"], 20)
    ema50 = ta.ema(df["close"], 50)
    ema200 = ta.ema(df["close"], 200)
    f["ema_cross_20_50"]  = (ema20 - ema50) / df["close"]
    f["ema_cross_50_200"] = (ema50 - ema200) / df["close"]
    f["price_vs_ema20"]   = (df["close"] - ema20) / ema20
    f["trend_regime"]     = (ema50 > ema200).astype(int)

    # ── Volatility ─────────────────────────────────────────
    atr14 = ta.atr(df["high"], df["low"], df["close"], 14)
    f["atr_14"]      = atr14 / df["close"]  # Normalized ATR
    f["atr_ratio"]   = atr14 / ta.atr(df["high"], df["low"], df["close"], 56)
    f["vol_5"]       = df["close"].pct_change().rolling(5).std()
    f["vol_20"]      = df["close"].pct_change().rolling(20).std()
    f["vol_regime"]  = f["vol_5"] / f["vol_20"]  # >1 = expanding volatility

    # ── Bollinger Bands ────────────────────────────────────
    bb = ta.bbands(df["close"], length=20, std=2)
    if bb is not None:
        f["bb_pct"]   = bb.get("BBP_20_2.0", np.nan)
        f["bb_width"] = bb.get("BBB_20_2.0", np.nan)

    # ── Volume ─────────────────────────────────────────────
    vol_ma = df["volume"].rolling(20).mean()
    vol_std = df["volume"].rolling(20).std()
    f["vol_zscore"] = (df["volume"] - vol_ma) / vol_std
    f["vol_ratio"]  = df["volume"] / vol_ma

    # ── MACD ───────────────────────────────────────────────
    macd = ta.macd(df["close"])
    if macd is not None:
        f["macd_hist"] = macd.get("MACDh_12_26_9", np.nan)
        f["macd_sig"]  = macd.get("MACDs_12_26_9", np.nan)

    # ── Stochastic ─────────────────────────────────────────
    stoch = ta.stoch(df["high"], df["low"], df["close"])
    if stoch is not None:
        f["stoch_k"] = stoch.get("STOCHk_14_3_3", np.nan)
        f["stoch_d"] = stoch.get("STOCHd_14_3_3", np.nan)

    # ── Intraday patterns ──────────────────────────────────
    f["high_low_pct"] = (df["high"] - df["low"]) / df["close"]
    f["close_vs_high"] = (df["close"] - df["low"]) / (df["high"] - df["low"] + 1e-8)
    f["hour_of_day"]   = df.index.hour                     # Session timing
    f["day_of_week"]   = df.index.dayofweek                # Day of week effect

    return f


def build_macro_features(df_price: pd.DataFrame,
                          df_alt: pd.DataFrame) -> pd.DataFrame:
    """
    Macro and cross-asset features.
    Uses ASOF join (forward-fill) to avoid look-ahead from daily/weekly alt data.
    """
    f = pd.DataFrame(index=df_price.index)

    if df_alt.empty:
        logger.warning("Alt data empty — macro features will be NaN")
        return f

    # Reindex alt data to price timeframe (forward-fill)
    alt_aligned = df_alt.reindex(df_price.index, method="ffill")

    # ── Dollar Index ───────────────────────────────────────
    if "dxy" in alt_aligned.columns:
        f["dxy_ret_1d"]  = alt_aligned["dxy"].pct_change(1)
        f["dxy_ret_5d"]  = alt_aligned["dxy"].pct_change(5)
        f["dxy_vs_ma20"] = (alt_aligned["dxy"] - alt_aligned["dxy"].rolling(20).mean()) / alt_aligned["dxy"]

    # ── Real Yields (most important for gold) ──────────────
    if "tips_10y" in alt_aligned.columns:
        f["real_yield"]     = alt_aligned["tips_10y"]
        f["real_yield_chg"] = alt_aligned["tips_10y"].diff(5)  # 5-day change

    # ── Inflation Breakeven ────────────────────────────────
    if "breakeven" in alt_aligned.columns:
        f["breakeven"]     = alt_aligned["breakeven"]
        f["breakeven_chg"] = alt_aligned["breakeven"].diff(5)

    # ── VIX ────────────────────────────────────────────────
    if "vix" in alt_aligned.columns:
        f["vix_level"]  = alt_aligned["vix"]
        f["vix_change"] = alt_aligned["vix"].pct_change(1)
        f["vix_regime"] = (alt_aligned["vix"] > 25).astype(int)

    # ── Gold Volatility Index ──────────────────────────────
    if "gvz" in alt_aligned.columns:
        f["gvz_level"]  = alt_aligned["gvz"]
        f["gvz_regime"] = pd.cut(alt_aligned["gvz"],
                                  bins=[0, 15, 25, 35, 100],
                                  labels=[0, 1, 2, 3]).astype(float)

    # ── Silver Ratio ───────────────────────────────────────
    if "silver" in alt_aligned.columns and "close" in df_price.columns:
        f["gold_silver_ratio"] = df_price["close"] / alt_aligned["silver"]
        f["gsr_zscore"]        = (f["gold_silver_ratio"] - f["gold_silver_ratio"].rolling(50).mean()) / \
                                  f["gold_silver_ratio"].rolling(50).std()

    # ── COT Positioning ────────────────────────────────────
    if "nc_net" in alt_aligned.columns:
        f["cot_nc_net"]     = alt_aligned["nc_net"]
        f["cot_nc_net_pct"] = alt_aligned["nc_net_pct"]
        f["cot_extreme_long"]  = (alt_aligned["nc_net_pct"] > 0.90).astype(int)
        f["cot_extreme_short"] = (alt_aligned["nc_net_pct"] < 0.10).astype(int)

    # ── Credit Spread ──────────────────────────────────────
    if "credit_spread" in alt_aligned.columns:
        f["credit_spread"]     = alt_aligned["credit_spread"]
        f["credit_spread_chg"] = alt_aligned["credit_spread"].diff(5)

    return f


def build_feature_matrix(df_ohlcv: pd.DataFrame,
                          df_alt: pd.DataFrame = None,
                          horizon: int = None) -> tuple[pd.DataFrame, pd.Series]:
    """
    Main entry point. Builds complete feature matrix + target.

    Args:
        df_ohlcv: OHLCV DataFrame with DatetimeIndex
        df_alt:   Alternative data (macro, COT) — optional
        horizon:  Forward bars for target. Default from config.

    Returns:
        X: Feature matrix (no NaNs, no look-ahead)
        y: Binary target (1=up, 0=down over next `horizon` bars)
    """
    if horizon is None:
        horizon = FEATURES["target_horizon"]

    if df_alt is None:
        # Try to load from cache
        try:
            from data.fetch_alt_data import load_all_alt_data
            df_alt = load_all_alt_data()
        except Exception:
            df_alt = pd.DataFrame()

    price_feat = build_price_features(df_ohlcv)
    macro_feat = build_macro_features(df_ohlcv, df_alt)

    X = pd.concat([price_feat, macro_feat], axis=1)

    # Target: will the close be higher in `horizon` bars?
    # Shift backwards so we're predicting the FUTURE — no look-ahead
    y = (df_ohlcv["close"].shift(-horizon) > df_ohlcv["close"]).astype(int)

    # Drop the last `horizon` rows (no target available yet)
    X = X.iloc[:-horizon]
    y = y.iloc[:-horizon]

    # Drop warmup rows and NaN rows
    warmup = FEATURES["warmup_bars"]
    X = X.iloc[warmup:]
    y = y.iloc[warmup:]

    X = X.replace([np.inf, -np.inf], np.nan)
    valid_mask = X.notna().all(axis=1)
    X = X[valid_mask]
    y = y[valid_mask]

    logger.info(f"Feature matrix: {X.shape[0]:,} rows × {X.shape[1]} features")
    logger.info(f"Target balance: {y.mean():.2%} positive (up)")

    return X, y


def get_sequence_data(df_ohlcv: pd.DataFrame,
                       df_alt: pd.DataFrame = None,
                       seq_len: int = None) -> tuple:
    """
    Builds 3D sequences (samples × time × features) for the LSTM.
    Returns (X_seq, y_seq) where X_seq.shape = (N, seq_len, n_features).
    """
    if seq_len is None:
        seq_len = FEATURES["seq_len"]

    X_flat, y = build_feature_matrix(df_ohlcv, df_alt)

    # Normalize features (z-score per feature using rolling window)
    X_norm = X_flat.copy()
    for col in X_flat.columns:
        roll_mean = X_flat[col].rolling(252, min_periods=50).mean()
        roll_std  = X_flat[col].rolling(252, min_periods=50).std().clip(lower=1e-8)
        X_norm[col] = (X_flat[col] - roll_mean) / roll_std

    X_norm = X_norm.fillna(0).clip(-5, 5)  # Cap outliers

    # Build sequences
    vals = X_norm.values
    target = y.values

    sequences, labels = [], []
    for i in range(seq_len, len(vals)):
        sequences.append(vals[i - seq_len: i])
        labels.append(target[i])

    import torch
    X_seq = torch.tensor(np.array(sequences), dtype=torch.float32)
    y_seq = torch.tensor(np.array(labels),    dtype=torch.float32)

    logger.info(f"LSTM sequences: {X_seq.shape}")
    return X_seq, y_seq
