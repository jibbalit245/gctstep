"""
models/ensemble.py
Loads trained LightGBM + LSTM models and generates combined trading signals.
This is the inference engine used by the live bot.

Usage:
    from models.ensemble import SignalEngine
    engine = SignalEngine()
    signal = engine.predict(df_recent_bars, df_alt)
    # Returns: 1 (long), -1 (short), 0 (flat)
"""

import numpy as np
import torch
import joblib
from pathlib import Path
from loguru import logger
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import SIGNAL, MODEL_DIR, FEATURES
from models.train_lstm import GoldLSTM


class SignalEngine:
    """
    Loads saved models and generates real-time trading signals.
    Call predict() on each new bar.
    """

    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.lgbm_model   = None
        self.lgbm_features = None
        self.lstm_model   = None
        self.seq_len      = FEATURES["seq_len"]
        self._load_models()

    def _load_models(self):
        lgbm_path     = MODEL_DIR / "gc_lgbm_latest.pkl"
        features_path = MODEL_DIR / "gc_lgbm_features.pkl"
        lstm_path     = MODEL_DIR / "gc_lstm_latest.pth"

        # Load LightGBM
        if lgbm_path.exists():
            self.lgbm_model    = joblib.load(lgbm_path)
            self.lgbm_features = joblib.load(features_path)
            logger.info(f"LightGBM loaded: {lgbm_path.name}")
        else:
            logger.warning(f"LightGBM model not found at {lgbm_path}")
            logger.warning("Run: python models/train_lgbm.py")

        # Load LSTM
        if lstm_path.exists():
            checkpoint = torch.load(lstm_path, map_location=self.device)
            cfg = checkpoint["model_config"]
            self.lstm_model = GoldLSTM(
                input_size=cfg["input_size"],
                hidden_size=cfg["hidden_size"],
                num_layers=cfg["num_layers"],
                dropout=cfg["dropout"],
                num_heads=cfg["num_heads"],
            ).to(self.device)
            self.lstm_model.load_state_dict(checkpoint["model_state_dict"])
            self.lstm_model.eval()
            logger.info(f"LSTM loaded: {lstm_path.name} "
                        f"(val_loss={checkpoint.get('val_loss', '?'):.4f}, "
                        f"test_acc={checkpoint.get('test_acc', '?'):.4f})")
        else:
            logger.warning(f"LSTM model not found at {lstm_path}")
            logger.warning("Run: python models/train_lstm.py")

    def predict(self, df_recent, df_alt=None) -> int:
        """
        Generate a trading signal from the most recent bars.

        Args:
            df_recent: DataFrame with at least seq_len + 50 bars of OHLCV data
            df_alt: Alternative/macro data aligned to same timeframe

        Returns:
            1  = go long
            -1 = go short
            0  = stay flat (low confidence)
        """
        prob = self._get_probability(df_recent, df_alt)
        if prob is None:
            return 0

        if prob > SIGNAL["long_thresh"]:
            return 1
        elif prob < SIGNAL["short_thresh"]:
            return -1
        return 0

    def _get_probability(self, df_recent, df_alt=None) -> float | None:
        """Returns raw probability (0-1) of upward move. None if models unavailable."""

        from models.features import build_feature_matrix, get_sequence_data
        import pandas as pd

        if len(df_recent) < self.seq_len + 50:
            logger.debug(f"Not enough bars ({len(df_recent)} < {self.seq_len + 50})")
            return None

        lgbm_prob = None
        lstm_prob = None

        # ── LightGBM inference ────────────────────────────────────────────────
        if self.lgbm_model is not None:
            try:
                X, _ = build_feature_matrix(df_recent, df_alt)
                # Get last row only (most recent bar)
                last_row = X[self.lgbm_features].iloc[[-1]]
                lgbm_prob = float(self.lgbm_model.predict(last_row)[0])
            except Exception as e:
                logger.error(f"LightGBM inference error: {e}")

        # ── LSTM inference ────────────────────────────────────────────────────
        if self.lstm_model is not None:
            try:
                X_seq, _ = get_sequence_data(df_recent, df_alt)
                if len(X_seq) > 0:
                    last_seq = X_seq[[-1]].to(self.device)
                    with torch.no_grad():
                        lstm_prob = float(self.lstm_model(last_seq).squeeze())
            except Exception as e:
                logger.error(f"LSTM inference error: {e}")

        # ── Ensemble ──────────────────────────────────────────────────────────
        if lgbm_prob is not None and lstm_prob is not None:
            prob = (SIGNAL["lgbm_weight"] * lgbm_prob +
                    SIGNAL["lstm_weight"]  * lstm_prob)
        elif lgbm_prob is not None:
            prob = lgbm_prob
            logger.debug("Using LightGBM only (LSTM unavailable)")
        elif lstm_prob is not None:
            prob = lstm_prob
            logger.debug("Using LSTM only (LightGBM unavailable)")
        else:
            logger.warning("No models available for inference")
            return None

        logger.debug(f"LGBM: {lgbm_prob:.3f} | LSTM: {lstm_prob:.3f} | "
                     f"Ensemble: {prob:.3f}")
        return prob

    def signal_strength(self, df_recent, df_alt=None) -> dict:
        """Returns detailed signal info including raw probabilities."""
        from models.features import build_feature_matrix, get_sequence_data

        prob = self._get_probability(df_recent, df_alt)
        if prob is None:
            return {"signal": 0, "probability": None, "confidence": "none"}

        signal = self.predict(df_recent, df_alt)
        confidence = "high" if (prob > 0.72 or prob < 0.28) else \
                     "medium" if (prob > 0.60 or prob < 0.40) else "low"

        return {
            "signal": signal,
            "probability": round(prob, 4),
            "confidence": confidence,
            "long_threshold":  SIGNAL["long_thresh"],
            "short_threshold": SIGNAL["short_thresh"],
        }
