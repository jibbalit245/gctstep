"""
models/shap_analysis.py
SHAP-based feature importance and debugging for the LightGBM model.
Run this after training to understand what the model is actually learning.

Usage:
    python models/shap_analysis.py
"""

import shap
import joblib
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from loguru import logger
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import MODEL_DIR, BASE_DIR

CACHE_DIR = BASE_DIR / "data" / "cache"


def run_shap_analysis(n_samples: int = 2000):
    # Load model
    model_path = MODEL_DIR / "gc_lgbm_latest.pkl"
    if not model_path.exists():
        logger.error(f"Model not found at {model_path}. Run train_lgbm.py first.")
        sys.exit(1)

    model    = joblib.load(model_path)
    features = joblib.load(MODEL_DIR / "gc_lgbm_features.pkl")
    logger.info(f"Loaded model with {len(features)} features")

    # Load features
    ohlcv_path = CACHE_DIR / "gc_ohlcv_1h.parquet"
    df = pd.read_parquet(ohlcv_path)

    from models.features import build_feature_matrix
    from data.fetch_alt_data import load_all_alt_data
    df_alt = load_all_alt_data()
    X, y   = build_feature_matrix(df, df_alt)

    # Use recent data for SHAP
    X_shap = X[features].iloc[-n_samples:]
    logger.info(f"Running SHAP on {len(X_shap):,} samples...")

    explainer   = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_shap)
    sv = shap_values[1] if isinstance(shap_values, list) else shap_values

    output_dir = BASE_DIR / "outputs"
    output_dir.mkdir(exist_ok=True)

    # Summary plot
    plt.figure(figsize=(10, 8))
    shap.summary_plot(sv, X_shap, show=False)
    plt.title("SHAP Feature Importance — GC Gold Futures")
    plt.tight_layout()
    plt.savefig(output_dir / "shap_summary.png", dpi=150, bbox_inches="tight")
    logger.info(f"Saved: {output_dir / 'shap_summary.png'}")
    plt.close()

    # Bar chart
    plt.figure(figsize=(8, 6))
    shap.summary_plot(sv, X_shap, plot_type="bar", show=False)
    plt.title("Mean |SHAP| by Feature")
    plt.tight_layout()
    plt.savefig(output_dir / "shap_bar.png", dpi=150, bbox_inches="tight")
    plt.close()

    # Top feature table
    mean_shap = pd.DataFrame({
        "feature":    features,
        "mean_shap":  abs(sv).mean(axis=0),
    }).sort_values("mean_shap", ascending=False)

    logger.info("\nTop 20 features by mean |SHAP|:")
    logger.info(mean_shap.head(20).to_string(index=False))

    return mean_shap


if __name__ == "__main__":
    run_shap_analysis()
