"""
models/train_lstm.py
LSTM + attention model for GC gold futures temporal signal extraction.
Runs on GPU (Paperspace A100) — falls back to CPU if no GPU available.

Usage:
    python models/train_lstm.py
"""

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from pathlib import Path
from loguru import logger
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LSTM_PARAMS, MODEL_DIR, BASE_DIR, FEATURES

CACHE_DIR = BASE_DIR / "data" / "cache"


# ── Model Architecture ──────────────────────────────────────────────────────────

class GoldLSTM(nn.Module):
    """
    LSTM + multi-head attention for temporal gold price pattern detection.
    Input:  (batch, seq_len, n_features)
    Output: (batch, 1) probability of price going up
    """
    def __init__(self, input_size: int,
                 hidden_size: int  = 128,
                 num_layers: int   = 2,
                 dropout: float    = 0.3,
                 num_heads: int    = 4):
        super().__init__()

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )

        self.attention = nn.MultiheadAttention(
            embed_dim=hidden_size,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True,
        )

        self.layer_norm = nn.LayerNorm(hidden_size)

        self.fc = nn.Sequential(
            nn.Linear(hidden_size, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(dropout / 2),
            nn.Linear(32, 1),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        lstm_out, _ = self.lstm(x)                              # (B, T, H)
        attn_out, _ = self.attention(lstm_out, lstm_out, lstm_out)  # (B, T, H)
        out = self.layer_norm(lstm_out + attn_out)              # Residual + norm
        return self.fc(out[:, -1, :])                           # Last timestep


# ── Training Loop ───────────────────────────────────────────────────────────────

def train_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0.0
    for X_batch, y_batch in loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)
        optimizer.zero_grad()
        preds = model(X_batch).squeeze()
        loss = criterion(preds, y_batch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(loader)


def eval_epoch(model, loader, criterion, device):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0
    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            preds = model(X_batch).squeeze()
            loss = criterion(preds, y_batch)
            total_loss += loss.item()
            predicted = (preds > 0.5).float()
            correct += (predicted == y_batch).sum().item()
            total += y_batch.size(0)
    return total_loss / len(loader), correct / total


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logger.info(f"Training on: {device}")
    if device.type == "cuda":
        logger.info(f"GPU: {torch.cuda.get_device_name(0)}")

    # Load data
    ohlcv_file = CACHE_DIR / "gc_ohlcv_1h.parquet"
    if not ohlcv_file.exists():
        logger.error("OHLCV cache not found. Run: python data/fetch_databento.py")
        sys.exit(1)

    import pandas as pd
    df = pd.read_parquet(ohlcv_file)

    from models.features import get_sequence_data
    from data.fetch_alt_data import load_all_alt_data
    df_alt = load_all_alt_data()

    X_seq, y_seq = get_sequence_data(df, df_alt)
    logger.info(f"Sequences: {X_seq.shape}, Labels: {y_seq.shape}")

    # Walk-forward split: 70% train, 15% val, 15% test
    n = len(X_seq)
    train_end = int(n * 0.70)
    val_end   = int(n * 0.85)

    X_train, y_train = X_seq[:train_end], y_seq[:train_end]
    X_val,   y_val   = X_seq[train_end:val_end], y_seq[train_end:val_end]
    X_test,  y_test  = X_seq[val_end:], y_seq[val_end:]

    # Dataloaders
    batch_size = LSTM_PARAMS["batch_size"]
    train_loader = DataLoader(TensorDataset(X_train, y_train),
                              batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader   = DataLoader(TensorDataset(X_val, y_val),
                              batch_size=batch_size * 2)

    # Model
    input_size = X_seq.shape[2]
    model = GoldLSTM(
        input_size=input_size,
        hidden_size=LSTM_PARAMS["hidden_size"],
        num_layers=LSTM_PARAMS["num_layers"],
        dropout=LSTM_PARAMS["dropout"],
        num_heads=LSTM_PARAMS["num_heads"],
    ).to(device)

    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"Model parameters: {total_params:,}")

    optimizer = torch.optim.AdamW(model.parameters(),
                                   lr=LSTM_PARAMS["lr"],
                                   weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=LSTM_PARAMS["epochs"])
    criterion = nn.BCELoss()

    # Training loop with early stopping
    best_val_loss = float("inf")
    patience_counter = 0
    best_state = None

    for epoch in range(1, LSTM_PARAMS["epochs"] + 1):
        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = eval_epoch(model, val_loader, criterion, device)
        scheduler.step()

        if epoch % 5 == 0 or epoch == 1:
            logger.info(f"Epoch {epoch:3d}/{LSTM_PARAMS['epochs']} | "
                        f"Train: {train_loss:.4f} | Val: {val_loss:.4f} | "
                        f"Val Acc: {val_acc:.4f} | "
                        f"LR: {scheduler.get_last_lr()[0]:.2e}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= LSTM_PARAMS["patience"]:
                logger.info(f"Early stopping at epoch {epoch}")
                break

    # Restore best weights
    model.load_state_dict(best_state)

    # Test evaluation
    test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=batch_size * 2)
    test_loss, test_acc = eval_epoch(model, test_loader, criterion, device)
    logger.success(f"Test Loss: {test_loss:.4f} | Test Accuracy: {test_acc:.4f}")

    # Save model
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model_path = MODEL_DIR / "gc_lstm_latest.pth"
    meta_path  = MODEL_DIR / "gc_lstm_meta.pkl"

    torch.save({
        "model_state_dict": best_state,
        "model_config": {
            "input_size": input_size,
            "hidden_size": LSTM_PARAMS["hidden_size"],
            "num_layers": LSTM_PARAMS["num_layers"],
            "dropout": LSTM_PARAMS["dropout"],
            "num_heads": LSTM_PARAMS["num_heads"],
        },
        "val_loss": best_val_loss,
        "test_acc": test_acc,
    }, model_path)

    import joblib
    joblib.dump({"seq_len": FEATURES["seq_len"], "input_size": input_size}, meta_path)

    logger.success(f"LSTM saved: {model_path}")


if __name__ == "__main__":
    main()
