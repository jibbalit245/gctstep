"""
models/train_lgbm.py
Walk-forward training of LightGBM direction classifier for GC gold futures.
Saves the final model to models/saved/gc_lgbm_latest.pkl

Usage:
    python models/train_lgbm.py
    python models/train_lgbm.py --tune   # Run Optuna hyperparameter search first
"""

import argparse
import joblib
import numpy as np
import pandas as pd
import lightgbm as lgb
from pathlib import Path
from loguru import logger
from sklearn.metrics import roc_auc_score, accuracy_score
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import LGBM_PARAMS, LGBM_TRAINING, MODEL_DIR, BASE_DIR

CACHE_DIR = BASE_DIR / "data" / "cache"


def walk_forward_train(X: pd.DataFrame, y: pd.Series,
                        params: dict = None) -> tuple[lgb.Booster, list]:
    """
    Walk-forward (expanding window) cross-validation.
    Returns the model trained on the last fold + fold metrics.
    """
    if params is None:
        params = LGBM_PARAMS

    n = len(X)
    n_splits    = LGBM_TRAINING["n_splits"]
    train_pct   = LGBM_TRAINING["train_pct"]
    val_pct     = LGBM_TRAINING["val_pct"]

    fold_metrics = []
    last_model = None

    for i in range(n_splits):
        train_end = int(n * (train_pct + i * val_pct))
        val_end   = min(train_end + int(n * val_pct), n)

        if val_end > n:
            break

        X_train = X.iloc[:train_end]
        y_train = y.iloc[:train_end]
        X_val   = X.iloc[train_end:val_end]
        y_val   = y.iloc[train_end:val_end]

        train_data = lgb.Dataset(X_train, label=y_train)
        val_data   = lgb.Dataset(X_val,   label=y_val, reference=train_data)

        model = lgb.train(
            params,
            train_data,
            valid_sets=[val_data],
            num_boost_round=LGBM_TRAINING["num_boost_round"],
            callbacks=[
                lgb.early_stopping(LGBM_TRAINING["early_stopping"]),
                lgb.log_evaluation(200),
            ],
        )

        preds = model.predict(X_val)
        auc   = roc_auc_score(y_val, preds)
        acc   = accuracy_score(y_val, (preds > 0.5).astype(int))

        fold_metrics.append({"fold": i+1, "auc": auc, "acc": acc,
                              "train_size": len(X_train), "val_size": len(X_val)})
        logger.info(f"Fold {i+1}/{n_splits} | AUC: {auc:.4f} | ACC: {acc:.4f} "
                    f"| Train: {len(X_train):,} | Val: {len(X_val):,}")
        last_model = model

    return last_model, fold_metrics


def tune_hyperparameters(X: pd.DataFrame, y: pd.Series, n_trials: int = 50) -> dict:
    """
    Optuna hyperparameter search. Run with --tune flag.
    Takes ~30 min on CPU, ~10 min on GPU.
    """
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    def objective(trial):
        params = {
            "objective":        "binary",
            "metric":           "auc",
            "verbosity":        -1,
            "learning_rate":    trial.suggest_float("lr", 0.005, 0.05, log=True),
            "num_leaves":       trial.suggest_int("num_leaves", 31, 255),
            "feature_fraction": trial.suggest_float("feature_fraction", 0.5, 0.9),
            "bagging_fraction": trial.suggest_float("bagging_fraction", 0.5, 0.9),
            "bagging_freq":     trial.suggest_int("bagging_freq", 1, 10),
            "min_child_samples":trial.suggest_int("min_child_samples", 20, 100),
            "lambda_l1":        trial.suggest_float("lambda_l1", 0.0, 1.0),
            "lambda_l2":        trial.suggest_float("lambda_l2", 0.0, 1.0),
        }

        # Quick 3-fold eval for tuning
        split = int(len(X) * 0.7)
        val_split = int(len(X) * 0.85)

        model = lgb.train(
            params,
            lgb.Dataset(X.iloc[:split], y.iloc[:split]),
            valid_sets=[lgb.Dataset(X.iloc[split:val_split], y.iloc[split:val_split])],
            num_boost_round=300,
            callbacks=[lgb.early_stopping(30), lgb.log_evaluation(-1)],
        )
        preds = model.predict(X.iloc[val_split:])
        return roc_auc_score(y.iloc[val_split:], preds)

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=n_trials, show_progress_bar=True)

    best = study.best_params
    best.update({"objective": "binary", "metric": "auc", "verbosity": -1,
                 "device": "gpu"})

    logger.success(f"Best AUC: {study.best_value:.4f}")
    logger.info(f"Best params: {best}")
    return best


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tune", action="store_true",
                        help="Run Optuna hyperparameter search (slower)")
    parser.add_argument("--trials", type=int, default=50,
                        help="Number of Optuna trials (default: 50)")
    args = parser.parse_args()

    # Load data
    ohlcv_file = CACHE_DIR / "gc_ohlcv_1h.parquet"
    if not ohlcv_file.exists():
        logger.error(f"OHLCV cache not found. Run: python data/fetch_databento.py")
        sys.exit(1)

    df = pd.read_parquet(ohlcv_file)
    logger.info(f"Loaded {len(df):,} bars from {df.index.min()} to {df.index.max()}")

    # Build features
    from models.features import build_feature_matrix
    from data.fetch_alt_data import load_all_alt_data
    df_alt = load_all_alt_data()
    X, y = build_feature_matrix(df, df_alt)

    logger.info(f"Training on {len(X):,} samples, {X.shape[1]} features")
    logger.info(f"Target distribution: {y.mean():.2%} positive")

    # Optionally tune
    params = LGBM_PARAMS.copy()
    if args.tune:
        logger.info(f"Running Optuna with {args.trials} trials...")
        params = tune_hyperparameters(X, y, n_trials=args.trials)

    # Walk-forward train
    model, metrics = walk_forward_train(X, y, params)

    # Print summary
    metrics_df = pd.DataFrame(metrics)
    logger.info("\n" + metrics_df.to_string())
    logger.info(f"Mean AUC: {metrics_df['auc'].mean():.4f} ± {metrics_df['auc'].std():.4f}")

    # Save model + feature names
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model_path    = MODEL_DIR / "gc_lgbm_latest.pkl"
    features_path = MODEL_DIR / "gc_lgbm_features.pkl"

    joblib.dump(model, model_path)
    joblib.dump(list(X.columns), features_path)

    logger.success(f"Model saved: {model_path}")
    logger.success(f"Features saved: {features_path}")

    # Quick feature importance
    importance = pd.DataFrame({
        "feature": model.feature_name(),
        "importance": model.feature_importance(importance_type="gain"),
    }).sort_values("importance", ascending=False)

    logger.info("\nTop 15 features by gain:\n" + importance.head(15).to_string())


if __name__ == "__main__":
    main()
